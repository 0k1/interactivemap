﻿
module JsonResponse {
     export var  Response: string = `"{
        "Districts": {
            "Kasaragod": {
                "Spot": [
                    {
                        "SpotName": "Spot1",
        "Type": "Type1"
    },
    {
        "SpotName": "Spot2",
            "Type": "Type2"
    },
    {
        "SpotName": "Spot3",
            "Type": "Type3"
    }
            ]
},
"Kannur": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Kozhikode": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Wayanad": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Malappuram": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Thrissur": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Palaghat": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Ernakulam": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Idukki": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Kottayam": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Pathanamthitta": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Aleppy": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Kollam": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
},
"Trivandrum": {
    "Spot": [
        {
            "SpotName": "Spot1",
            "Type": "Type1"
        },
        {
            "SpotName": "Spot2",
            "Type": "Type2"
        },
        {
            "SpotName": "Spot3",
            "Type": "Type3"
        }
    ]
}
    }
}"`;


  

}


