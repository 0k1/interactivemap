﻿module Project{
    export class District {

        SpotArray: string[];
        TypeArray: string[];
    }

}

