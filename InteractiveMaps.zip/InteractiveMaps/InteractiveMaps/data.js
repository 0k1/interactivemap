var Project;
(function (Project) {
    var District = (function () {
        function District() {
        }
        return District;
    })();
    Project.District = District;
})(Project || (Project = {}));
//# sourceMappingURL=data.js.map